/**
 * TraceBack Data Adapter Abstraction Layer
 * 
 * Provides transparent switching between:
 * 1. Local JSON store (default for development/offline testing)
 * 2. AWS DynamoDB DocumentClient adapter (for cloud DynamoDB integration)
 * 
 * Switch is controlled by environment variable:
 * DATA_ADAPTER=dynamodb | local
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const DynamoDbAdapter = require('./dynamoDbAdapter');

const DATA_FILE = process.env.LOCAL_DATA_FILE
  ? path.resolve(process.cwd(), process.env.LOCAL_DATA_FILE)
  : path.resolve(__dirname, './localStore.json');

class LocalDataAdapter {
  constructor() {
    this.type = 'local';
    this.store = {
      users: [],
      reports: [],
      matches: [],
      notifications: [],
      claims: [],
      disputes: [],
    };
    this.isLoaded = false;
    this.init();
  }

  init() {
    try {
      const dataDir = path.dirname(DATA_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        if (raw.trim()) {
          this.store = JSON.parse(raw);
          this.store.users = this.store.users || [];
          this.store.reports = this.store.reports || [];
          this.store.matches = this.store.matches || [];
          this.store.notifications = this.store.notifications || [];
          this.store.claims = this.store.claims || [];
          this.store.disputes = this.store.disputes || [];
          this.isLoaded = true;
          logger.info(`Loaded local store from ${DATA_FILE}`);
          return;
        }
      }
      this.persist();
      this.isLoaded = true;
    } catch (err) {
      logger.error('Failed to initialize local data adapter', err);
      this.isLoaded = true;
    }
  }

  persist() {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(this.store, null, 2), 'utf-8');
    } catch (err) {
      logger.error('Failed to persist local store', err);
    }
  }

  _getCollection(collection) {
    if (!this.store[collection]) {
      this.store[collection] = [];
    }
    return this.store[collection];
  }

  _matchesItemKey(collection, item, idOrKey) {
    if (collection === 'notifications' && typeof idOrKey === 'object' && idOrKey !== null) {
      const notifId = idOrKey.notificationId || idOrKey.id;
      return item.userId === idOrKey.userId && (item.id === notifId || item.notificationId === notifId);
    }
    const scalarId = typeof idOrKey === 'object' && idOrKey !== null
      ? (idOrKey.id || idOrKey.userId || idOrKey.reportId || idOrKey.matchId || idOrKey.claimId || idOrKey.disputeId || idOrKey.notificationId)
      : idOrKey;
    return item.id === scalarId;
  }

  _matchesQuery(item, query, collection) {
    if (!query || Object.keys(query).length === 0) return true;

    // Special match handling for matches collection when querying user matches
    if (collection === 'matches' && query.userId) {
      const uid = query.userId;
      const isOwner = (item.lostUserId && item.lostUserId === uid) ||
                      (item.foundUserId && item.foundUserId === uid) ||
                      (item.lostItem && (item.lostItem.userId === uid || item.lostItem.reportedBy?.id === uid)) ||
                      (item.foundItem && (item.foundItem.userId === uid || item.foundItem.reportedBy?.id === uid));
      if (!isOwner) return false;
      if (query.status && item.status !== query.status) return false;
      return true;
    }

    // Special dispute participant check
    if (collection === 'disputes' && query.participantUserId) {
      const uid = query.participantUserId;
      const isParticipant = item.submittedBy === uid ||
                            (item.claimant1 && item.claimant1.id === uid) ||
                            (item.claimant2 && (item.claimant2.id === uid || item.claimant2 === uid)) ||
                            item.userId === uid ||
                            item.claimantId === uid;
      if (!isParticipant) return false;
      if (query.status && query.status !== 'all' && item.status !== query.status) return false;
      return true;
    }

    for (const [key, val] of Object.entries(query)) {
      if (key === 'userId' && collection === 'matches') continue;
      if (key === 'participantUserId' && collection === 'disputes') continue;

      if (typeof val === 'function') {
        if (!val(item[key], item)) return false;
      } else if (val !== undefined && item[key] !== val) {
        return false;
      }
    }
    return true;
  }

  async find(collection, query = {}, options = {}) {
    const list = this._getCollection(collection);
    let results = list.filter(item => this._matchesQuery(item, query, collection));

    // Sorting
    if (options.sortBy) {
      const field = options.sortBy;
      const order = options.sortOrder === 'asc' ? 1 : -1;
      results.sort((a, b) => {
        if (a[field] < b[field]) return -1 * order;
        if (a[field] > b[field]) return 1 * order;
        return 0;
      });
    }

    // Pagination
    if (options.limit) {
      const page = options.page || 1;
      const skip = (page - 1) * options.limit;
      results = results.slice(skip, skip + options.limit);
    }

    return results;
  }

  async findById(collection, idOrKey) {
    const list = this._getCollection(collection);
    const found = list.find(item => this._matchesItemKey(collection, item, idOrKey));
    return found ? { ...found } : null;
  }

  async findOne(collection, query) {
    const list = this._getCollection(collection);
    const found = list.find(item => this._matchesQuery(item, query, collection));
    return found ? { ...found } : null;
  }

  async create(collection, data) {
    const list = this._getCollection(collection);
    const now = new Date().toISOString();
    const rawId = data.id || `${collection.slice(0, 3)}_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

    const newItem = {
      ...data,
      id: rawId,
      createdAt: data.createdAt || data.submittedAt || now,
      updatedAt: data.updatedAt || now,
    };

    if (collection === 'notifications') {
      newItem.notificationId = data.notificationId || rawId;
    } else if (collection === 'matches') {
      newItem.matchId = rawId;
      newItem.lostUserId = data.lostUserId || data.lostItem?.userId || data.lostItem?.reportedBy?.id;
      newItem.foundUserId = data.foundUserId || data.foundItem?.userId || data.foundItem?.reportedBy?.id;
      newItem.status = data.status || 'suggested';
    } else if (collection === 'claims') {
      newItem.claimId = rawId;
      newItem.submittedAt = data.submittedAt || newItem.createdAt;
      newItem.createdAt = newItem.submittedAt;
    } else if (collection === 'disputes') {
      newItem.disputeId = rawId;
      newItem.submittedAt = data.submittedAt || newItem.createdAt;
      newItem.createdAt = newItem.submittedAt;
    } else if (collection === 'users') {
      newItem.userId = rawId;
    } else if (collection === 'reports') {
      newItem.reportId = rawId;
    }

    list.unshift(newItem);
    this.persist();
    return { ...newItem };
  }

  async update(collection, idOrKey, updateData) {
    const list = this._getCollection(collection);
    const index = list.findIndex(item => this._matchesItemKey(collection, item, idOrKey));
    if (index === -1) {
      return null;
    }
    const existing = list[index];
    const updated = {
      ...existing,
      ...updateData,
      id: existing.id,
      updatedAt: new Date().toISOString(),
    };
    list[index] = updated;
    this.persist();
    return { ...updated };
  }

  async delete(collection, idOrKey) {
    const list = this._getCollection(collection);
    const index = list.findIndex(item => this._matchesItemKey(collection, item, idOrKey));
    if (index === -1) return false;
    list.splice(index, 1);
    this.persist();
    return true;
  }

  async count(collection, query = {}) {
    const list = this._getCollection(collection);
    return list.filter(item => this._matchesQuery(item, query, collection)).length;
  }

  async seed(seedData) {
    for (const [col, items] of Object.entries(seedData)) {
      if (Array.isArray(items)) {
        this.store[col] = items;
      }
    }
    this.persist();
    logger.info('Database seeded successfully with local sample data');
  }

  getStore() {
    return this.store;
  }
}

// Instantiate adapter based on DATA_ADAPTER setting
let adapterInstance = null;
const isDynamoDb = process.env.DATA_ADAPTER === 'dynamodb';

if (isDynamoDb) {
  logger.info('[Adapter] Initializing AWS DynamoDB persistence adapter');
  adapterInstance = new DynamoDbAdapter();
} else {
  adapterInstance = new LocalDataAdapter();
}

// Proxy wrapper that dynamically resolves adapter according to process.env.DATA_ADAPTER
const adapterProxy = new Proxy({}, {
  get(target, prop) {
    const activeAdapter = process.env.DATA_ADAPTER === 'dynamodb'
      ? (adapterInstance instanceof DynamoDbAdapter ? adapterInstance : (adapterInstance = new DynamoDbAdapter()))
      : (adapterInstance instanceof LocalDataAdapter ? adapterInstance : (adapterInstance = new LocalDataAdapter()));

    if (prop === 'getAdapterType') {
      return () => process.env.DATA_ADAPTER === 'dynamodb' ? 'dynamodb' : 'local';
    }
    if (prop === 'getUnderlyingAdapter') {
      return () => activeAdapter;
    }
    const val = activeAdapter[prop];
    if (typeof val === 'function') {
      return val.bind(activeAdapter);
    }
    return val;
  }
});

module.exports = adapterProxy;
