/**
 * AWS DynamoDB Data Adapter for TraceBack Backend
 * 
 * Provides production NoSQL persistence using AWS SDK v3 DynamoDB DocumentClient.
 * Fully maps generic IDs to DynamoDB primary keys, implements composite keys,
 * and queries provisioned Global Secondary Indexes (GSIs).
 */

const {
  GetCommand,
  PutCommand,
  UpdateCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
} = require('@aws-sdk/lib-dynamodb');
const { dynamoDbDocClient, createDynamoDbDocClient, dynamoTableNames } = require('../config/aws');
const logger = require('../utils/logger');

const TABLE_SCHEMAS = {
  users: {
    name: () => dynamoTableNames.users,
    pk: 'userId',
    sk: null,
  },
  reports: {
    name: () => dynamoTableNames.reports,
    pk: 'reportId',
    sk: null,
  },
  matches: {
    name: () => dynamoTableNames.matches,
    pk: 'matchId',
    sk: null,
  },
  claims: {
    name: () => dynamoTableNames.claims,
    pk: 'claimId',
    sk: null,
  },
  disputes: {
    name: () => dynamoTableNames.disputes,
    pk: 'disputeId',
    sk: null,
  },
  notifications: {
    name: () => dynamoTableNames.notifications,
    pk: 'userId',
    sk: 'notificationId',
  },
};

class DynamoDbAdapter {
  constructor(customDocClient = null) {
    this.customDocClient = customDocClient;
  }

  getClient() {
    if (this.customDocClient) return this.customDocClient;
    if (dynamoDbDocClient) return dynamoDbDocClient;
    // Create new document client using credential provider chain
    return createDynamoDbDocClient();
  }

  _getSchema(collection) {
    const schema = TABLE_SCHEMAS[collection];
    if (!schema) {
      throw new Error(`[DynamoDB] Unknown collection: "${collection}"`);
    }
    return schema;
  }

  _getTableName(collection) {
    return this._getSchema(collection).name();
  }

  /**
   * Convert application model data to DynamoDB item
   * Ensures primary keys, composite keys, timestamps, and GSI attributes are properly set.
   */
  _toDynamoItem(collection, data) {
    const schema = this._getSchema(collection);
    const item = { ...data };
    const now = new Date().toISOString();

    const rawId = data.id || data[schema.pk] || `${collection.slice(0, 3)}_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;

    if (collection === 'notifications') {
      if (!data.userId) {
        throw new Error('[DynamoDB] Notification item requires top-level "userId" as partition key');
      }
      item.userId = data.userId;
      item.notificationId = data.notificationId || data.id || rawId;
      item.id = item.notificationId;
    } else {
      item[schema.pk] = data[schema.pk] || rawId;
      item.id = item[schema.pk];
    }

    // Explicitly populate createdAt and updatedAt
    item.createdAt = data.createdAt || data.submittedAt || now;
    item.updatedAt = data.updatedAt || now;

    // Entity-specific requirements:
    if (collection === 'matches') {
      // Must write top-level lostUserId and foundUserId for GSIs
      const lostUid = data.lostUserId || data.lostItem?.userId || data.lostItem?.reportedBy?.id;
      const foundUid = data.foundUserId || data.foundItem?.userId || data.foundItem?.reportedBy?.id;

      item.lostUserId = lostUid || 'unknown_lost_user';
      item.foundUserId = foundUid || 'unknown_found_user';
      item.status = data.status || 'suggested';
    }

    if (collection === 'claims') {
      // Must preserve both submittedAt and createdAt
      item.submittedAt = data.submittedAt || item.createdAt;
      item.createdAt = item.submittedAt;
    }

    if (collection === 'disputes') {
      item.submittedAt = data.submittedAt || item.createdAt;
      item.createdAt = item.submittedAt;
    }

    return item;
  }

  /**
   * Normalize DynamoDB item into application domain object
   * Ensures both generic "id" and entity primary keys are accessible.
   */
  _fromDynamoItem(collection, item) {
    if (!item) return null;
    const schema = this._getSchema(collection);
    const out = { ...item };

    if (collection === 'notifications') {
      out.id = item.notificationId || item.id;
      out.notificationId = out.id;
    } else {
      out.id = item[schema.pk] || item.id;
      out[schema.pk] = out.id;
    }

    return out;
  }

  /**
   * Build DynamoDB Key object
   * Handles composite primary keys (notifications) and scalar primary keys.
   */
  _buildKey(collection, idOrKey) {
    const schema = this._getSchema(collection);

    if (collection === 'notifications') {
      if (typeof idOrKey === 'object' && idOrKey !== null) {
        const userId = idOrKey.userId;
        const notificationId = idOrKey.notificationId || idOrKey.id;
        if (!userId || !notificationId) {
          throw new Error(`[DynamoDB] Notifications require composite key { userId, notificationId }, received: ${JSON.stringify(idOrKey)}`);
        }
        return { userId, notificationId };
      }
      throw new Error(`[DynamoDB] Notifications require composite key { userId, notificationId }, received scalar: ${idOrKey}`);
    }

    const idVal = typeof idOrKey === 'object' && idOrKey !== null
      ? (idOrKey[schema.pk] || idOrKey.id)
      : idOrKey;

    if (!idVal) {
      throw new Error(`[DynamoDB] Missing primary key for "${collection}": ${JSON.stringify(idOrKey)}`);
    }

    return { [schema.pk]: String(idVal) };
  }

  /**
   * Create (PutItem)
   */
  async create(collection, data) {
    const client = this.getClient();
    const TableName = this._getTableName(collection);
    const item = this._toDynamoItem(collection, data);

    await client.send(new PutCommand({
      TableName,
      Item: item,
    }));

    return this._fromDynamoItem(collection, item);
  }

  /**
   * GetItem by primary key
   */
  async findById(collection, idOrKey) {
    const client = this.getClient();
    const TableName = this._getTableName(collection);
    const Key = this._buildKey(collection, idOrKey);

    const res = await client.send(new GetCommand({
      TableName,
      Key,
    }));

    return this._fromDynamoItem(collection, res.Item);
  }

  /**
   * UpdateItem
   */
  async update(collection, idOrKey, updateData) {
    const client = this.getClient();
    const schema = this._getSchema(collection);
    const TableName = this._getTableName(collection);
    const Key = this._buildKey(collection, idOrKey);

    const excludeKeys = new Set(['id', schema.pk, schema.sk].filter(Boolean));
    const expressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};

    const dataToSet = {
      ...updateData,
      updatedAt: new Date().toISOString(),
    };

    let idx = 0;
    for (const [key, val] of Object.entries(dataToSet)) {
      if (excludeKeys.has(key) || val === undefined) continue;
      const nameKey = `#f${idx}`;
      const valKey = `:v${idx}`;
      expressions.push(`${nameKey} = ${valKey}`);
      expressionAttributeNames[nameKey] = key;
      expressionAttributeValues[valKey] = val;
      idx++;
    }

    if (expressions.length === 0) {
      return this.findById(collection, idOrKey);
    }

    const res = await client.send(new UpdateCommand({
      TableName,
      Key,
      UpdateExpression: `SET ${expressions.join(', ')}`,
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: 'ALL_NEW',
    }));

    return this._fromDynamoItem(collection, res.Attributes);
  }

  /**
   * DeleteItem
   */
  async delete(collection, idOrKey) {
    const client = this.getClient();
    const TableName = this._getTableName(collection);
    const Key = this._buildKey(collection, idOrKey);

    await client.send(new DeleteCommand({
      TableName,
      Key,
    }));

    return true;
  }

  /**
   * Query or Scan for single item
   */
  async findOne(collection, query = {}) {
    const results = await this.find(collection, query, { limit: 1 });
    return results.length > 0 ? results[0] : null;
  }

  /**
   * Query or Scan collection with support for all provisioned GSIs
   */
  async find(collection, query = {}, options = {}) {
    const client = this.getClient();
    const TableName = this._getTableName(collection);

    let items = [];

    switch (collection) {
      case 'users':
        items = await this._findUsers(client, TableName, query);
        break;

      case 'reports':
        items = await this._findReports(client, TableName, query);
        break;

      case 'matches':
        items = await this._findMatches(client, TableName, query);
        break;

      case 'claims':
        items = await this._findClaims(client, TableName, query);
        break;

      case 'disputes':
        items = await this._findDisputes(client, TableName, query);
        break;

      case 'notifications':
        items = await this._findNotifications(client, TableName, query);
        break;

      default:
        throw new Error(`[DynamoDB] Unsupported collection: ${collection}`);
    }

    // In-memory Sorting
    if (options.sortBy) {
      const field = options.sortBy;
      const order = options.sortOrder === 'asc' ? 1 : -1;
      items.sort((a, b) => {
        const valA = a[field] ?? '';
        const valB = b[field] ?? '';
        if (valA < valB) return -1 * order;
        if (valA > valB) return 1 * order;
        return 0;
      });
    }

    // In-memory Pagination
    if (options.limit) {
      const page = options.page || 1;
      const skip = (page - 1) * options.limit;
      items = items.slice(skip, skip + options.limit);
    }

    return items.map(item => this._fromDynamoItem(collection, item));
  }

  /**
   * Users Query/Scan
   * Uses EmailIndex (email) when queried by email.
   */
  async _findUsers(client, TableName, query) {
    if (query.email) {
      const email = String(query.email).toLowerCase().trim();
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'EmailIndex',
        KeyConditionExpression: '#email = :email',
        ExpressionAttributeNames: { '#email': 'email' },
        ExpressionAttributeValues: { ':email': email },
      }));
      return res.Items || [];
    }

    if (query.resetPasswordToken) {
      const res = await client.send(new ScanCommand({
        TableName,
        FilterExpression: '#token = :token',
        ExpressionAttributeNames: { '#token': 'resetPasswordToken' },
        ExpressionAttributeValues: { ':token': query.resetPasswordToken },
      }));
      let items = res.Items || [];
      if (typeof query.resetPasswordExpires === 'function') {
        items = items.filter(u => query.resetPasswordExpires(u.resetPasswordExpires));
      }
      return items;
    }

    // General user list (Admin)
    const res = await client.send(new ScanCommand({ TableName }));
    return res.Items || [];
  }

  /**
   * Reports Query/Scan
   * Supports:
   * 1. UserReportsIndex (userId, createdAt)
   * 2. TypeStatusIndex (type, createdAt)
   * 3. CategoryStatusIndex (category, status)
   */
  async _findReports(client, TableName, query) {
    // 1. By User ID -> UserReportsIndex
    if (query.userId) {
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'UserReportsIndex',
        KeyConditionExpression: '#userId = :userId',
        ExpressionAttributeNames: { '#userId': 'userId' },
        ExpressionAttributeValues: { ':userId': query.userId },
        ScanIndexForward: false, // Descending by createdAt
      }));
      return res.Items || [];
    }

    // 2. By Type -> TypeStatusIndex (type, createdAt)
    if (query.type) {
      const expNames = { '#type': 'type' };
      const expVals = { ':type': query.type };
      const filterParts = [];

      // Handle status filter
      if (typeof query.status === 'string') {
        expNames['#status'] = 'status';
        expVals[':status'] = query.status;
        filterParts.push('#status = :status');
      } else if (typeof query.status === 'function') {
        // Evaluate predicate for known report status exclusions
        expNames['#status'] = 'status';
        expVals[':cancelled'] = 'cancelled';
        expVals[':archived'] = 'archived';
        filterParts.push('#status <> :cancelled AND #status <> :archived');
      }

      if (query.category && query.category !== 'all') {
        expNames['#category'] = 'category';
        expVals[':category'] = query.category;
        filterParts.push('#category = :category');
      }

      const params = {
        TableName,
        IndexName: 'TypeStatusIndex',
        KeyConditionExpression: '#type = :type',
        ExpressionAttributeNames: expNames,
        ExpressionAttributeValues: expVals,
        ScanIndexForward: false,
      };

      if (filterParts.length > 0) {
        params.FilterExpression = filterParts.join(' AND ');
      }

      const res = await client.send(new QueryCommand(params));
      let items = res.Items || [];

      // Secondary function filter fallback if complex
      if (typeof query.status === 'function') {
        items = items.filter(r => query.status(r.status));
      }

      return items;
    }

    // 3. By Category & Status (without type) -> CategoryStatusIndex
    if (query.category && query.status && typeof query.status === 'string') {
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'CategoryStatusIndex',
        KeyConditionExpression: '#category = :category AND #status = :status',
        ExpressionAttributeNames: {
          '#category': 'category',
          '#status': 'status',
        },
        ExpressionAttributeValues: {
          ':category': query.category,
          ':status': query.status,
        },
      }));
      return res.Items || [];
    }

    // 4. Admin All Reports Scan
    const filterParts = [];
    const expNames = {};
    const expVals = {};

    if (query.category && query.category !== 'all') {
      expNames['#category'] = 'category';
      expVals[':category'] = query.category;
      filterParts.push('#category = :category');
    }
    if (query.status && typeof query.status === 'string' && query.status !== 'all') {
      expNames['#status'] = 'status';
      expVals[':status'] = query.status;
      filterParts.push('#status = :status');
    }

    const scanParams = { TableName };
    if (filterParts.length > 0) {
      scanParams.FilterExpression = filterParts.join(' AND ');
      scanParams.ExpressionAttributeNames = expNames;
      scanParams.ExpressionAttributeValues = expVals;
    }

    const res = await client.send(new ScanCommand(scanParams));
    let items = res.Items || [];
    if (typeof query.status === 'function') {
      items = items.filter(r => query.status(r.status));
    }
    return items;
  }

  /**
   * Matches Query/Scan
   * Supports:
   * 1. LostUserMatchesIndex (lostUserId, status)
   * 2. FoundUserMatchesIndex (foundUserId, status)
   * User matches query queries both indexes in parallel and merges.
   */
  async _findMatches(client, TableName, query) {
    const targetUserId = query.userId || query.lostUserId || query.foundUserId;

    if (targetUserId) {
      const queries = [];

      // Query LostUserMatchesIndex
      const lostParams = {
        TableName,
        IndexName: 'LostUserMatchesIndex',
        KeyConditionExpression: '#lostUserId = :uid',
        ExpressionAttributeNames: { '#lostUserId': 'lostUserId' },
        ExpressionAttributeValues: { ':uid': targetUserId },
      };
      if (query.status && typeof query.status === 'string') {
        lostParams.KeyConditionExpression += ' AND #status = :status';
        lostParams.ExpressionAttributeNames['#status'] = 'status';
        lostParams.ExpressionAttributeValues[':status'] = query.status;
      }
      queries.push(client.send(new QueryCommand(lostParams)).catch(() => ({ Items: [] })));

      // Query FoundUserMatchesIndex
      const foundParams = {
        TableName,
        IndexName: 'FoundUserMatchesIndex',
        KeyConditionExpression: '#foundUserId = :uid',
        ExpressionAttributeNames: { '#foundUserId': 'foundUserId' },
        ExpressionAttributeValues: { ':uid': targetUserId },
      };
      if (query.status && typeof query.status === 'string') {
        foundParams.KeyConditionExpression += ' AND #status = :status';
        foundParams.ExpressionAttributeNames['#status'] = 'status';
        foundParams.ExpressionAttributeValues[':status'] = query.status;
      }
      queries.push(client.send(new QueryCommand(foundParams)).catch(() => ({ Items: [] })));

      const [lostRes, foundRes] = await Promise.all(queries);
      const combined = [...(lostRes.Items || []), ...(foundRes.Items || [])];

      // Deduplicate by match ID
      const seen = new Set();
      const unique = [];
      for (const m of combined) {
        const id = m.matchId || m.id;
        if (!seen.has(id)) {
          seen.add(id);
          unique.push(m);
        }
      }

      // Application-level sort by createdAt DESC
      unique.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      return unique;
    }

    // Duplicate check: lostItemId and foundItemId
    if (query.lostItemId && query.foundItemId) {
      const res = await client.send(new ScanCommand({
        TableName,
        FilterExpression: '#lostItemId = :lid AND #foundItemId = :fid',
        ExpressionAttributeNames: {
          '#lostItemId': 'lostItemId',
          '#foundItemId': 'foundItemId',
        },
        ExpressionAttributeValues: {
          ':lid': query.lostItemId,
          ':fid': query.foundItemId,
        },
      }));
      return res.Items || [];
    }

    // Admin All Matches Scan
    const res = await client.send(new ScanCommand({ TableName }));
    return res.Items || [];
  }

  /**
   * Claims Query/Scan
   * Supports:
   * 1. ClaimantClaimsIndex (claimantId, createdAt)
   * 2. ItemClaimsIndex (itemId, createdAt)
   */
  async _findClaims(client, TableName, query) {
    if (query.claimantId) {
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'ClaimantClaimsIndex',
        KeyConditionExpression: '#claimantId = :claimantId',
        ExpressionAttributeNames: { '#claimantId': 'claimantId' },
        ExpressionAttributeValues: { ':claimantId': query.claimantId },
        ScanIndexForward: false, // Descending by createdAt
      }));
      return res.Items || [];
    }

    if (query.itemId) {
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'ItemClaimsIndex',
        KeyConditionExpression: '#itemId = :itemId',
        ExpressionAttributeNames: { '#itemId': 'itemId' },
        ExpressionAttributeValues: { ':itemId': query.itemId },
        ScanIndexForward: false,
      }));
      return res.Items || [];
    }

    // Admin All Claims Scan
    const scanParams = { TableName };
    if (query.status && query.status !== 'all') {
      scanParams.FilterExpression = '#status = :status';
      scanParams.ExpressionAttributeNames = { '#status': 'status' };
      scanParams.ExpressionAttributeValues = { ':status': query.status };
    }

    const res = await client.send(new ScanCommand(scanParams));
    return res.Items || [];
  }

  /**
   * Disputes Query/Scan
   * Uses filtered Scan for user-specific disputes checking submittedBy, claimant1.id, claimant2.id
   */
  async _findDisputes(client, TableName, query) {
    const targetUserId = query.participantUserId || query.userId || (typeof query.submittedBy === 'string' ? query.submittedBy : null);

    if (targetUserId) {
      const filterParts = [
        '(#submittedBy = :uid OR #claimant1.#id = :uid OR #claimant2.#id = :uid OR #claimant2 = :uid OR #claimantId = :uid OR #userId = :uid)'
      ];
      const expNames = {
        '#submittedBy': 'submittedBy',
        '#claimant1': 'claimant1',
        '#claimant2': 'claimant2',
        '#id': 'id',
        '#claimantId': 'claimantId',
        '#userId': 'userId',
      };
      const expVals = {
        ':uid': targetUserId,
      };

      if (query.status && query.status !== 'all') {
        expNames['#status'] = 'status';
        expVals[':status'] = query.status;
        filterParts.push('#status = :status');
      }

      const res = await client.send(new ScanCommand({
        TableName,
        FilterExpression: filterParts.join(' AND '),
        ExpressionAttributeNames: expNames,
        ExpressionAttributeValues: expVals,
      }));

      const items = res.Items || [];
      items.sort((a, b) => new Date(b.submittedAt || b.createdAt || 0) - new Date(a.submittedAt || a.createdAt || 0));
      return items;
    }

    // Admin All Disputes Scan
    const scanParams = { TableName };
    if (query.status && query.status !== 'all') {
      scanParams.FilterExpression = '#status = :status';
      scanParams.ExpressionAttributeNames = { '#status': 'status' };
      scanParams.ExpressionAttributeValues = { ':status': query.status };
    }

    const res = await client.send(new ScanCommand(scanParams));
    const items = res.Items || [];
    items.sort((a, b) => new Date(b.submittedAt || b.createdAt || 0) - new Date(a.submittedAt || a.createdAt || 0));
    return items;
  }

  /**
   * Notifications Query
   * Partition key is userId, Sort key is notificationId.
   */
  async _findNotifications(client, TableName, query) {
    if (!query.userId) {
      throw new Error('[DynamoDB] Querying notifications requires "userId" partition key');
    }

    const params = {
      TableName,
      KeyConditionExpression: '#userId = :userId',
      ExpressionAttributeNames: { '#userId': 'userId' },
      ExpressionAttributeValues: { ':userId': query.userId },
    };

    if (query.read !== undefined) {
      params.FilterExpression = '#read = :readVal';
      params.ExpressionAttributeNames['#read'] = 'read';
      params.ExpressionAttributeValues[':readVal'] = Boolean(query.read);
    }

    const res = await client.send(new QueryCommand(params));
    const items = res.Items || [];
    items.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    return items;
  }

  /**
   * Count items
   */
  async count(collection, query = {}) {
    const client = this.getClient();
    const TableName = this._getTableName(collection);

    // Notifications unread count
    if (collection === 'notifications' && query.userId) {
      const params = {
        TableName,
        KeyConditionExpression: '#userId = :userId',
        ExpressionAttributeNames: { '#userId': 'userId' },
        ExpressionAttributeValues: { ':userId': query.userId },
        Select: 'COUNT',
      };
      if (query.read !== undefined) {
        params.FilterExpression = '#read = :readVal';
        params.ExpressionAttributeNames['#read'] = 'read';
        params.ExpressionAttributeValues[':readVal'] = Boolean(query.read);
      }
      const res = await client.send(new QueryCommand(params));
      return res.Count || 0;
    }

    // Reports count by type
    if (collection === 'reports' && query.type) {
      const res = await client.send(new QueryCommand({
        TableName,
        IndexName: 'TypeStatusIndex',
        KeyConditionExpression: '#type = :type',
        ExpressionAttributeNames: { '#type': 'type' },
        ExpressionAttributeValues: { ':type': query.type },
        Select: 'COUNT',
      }));
      return res.Count || 0;
    }

    // General count via Scan with FilterExpression if present
    const scanParams = { TableName, Select: 'COUNT' };
    if (query.status && typeof query.status === 'string') {
      scanParams.FilterExpression = '#status = :status';
      scanParams.ExpressionAttributeNames = { '#status': 'status' };
      scanParams.ExpressionAttributeValues = { ':status': query.status };
    }

    const res = await client.send(new ScanCommand(scanParams));
    return res.Count || 0;
  }

  /**
   * Seed batch data into DynamoDB
   */
  async seed(seedData) {
    const client = this.getClient();
    for (const [col, items] of Object.entries(seedData)) {
      if (!Array.isArray(items) || items.length === 0) continue;
      const TableName = this._getTableName(col);
      for (const raw of items) {
        const item = this._toDynamoItem(col, raw);
        await client.send(new PutCommand({
          TableName,
          Item: item,
        }));
      }
      logger.info(`[DynamoDB] Seeded ${items.length} records into table: ${TableName}`);
    }
  }
}

module.exports = DynamoDbAdapter;
